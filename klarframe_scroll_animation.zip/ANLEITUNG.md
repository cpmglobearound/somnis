# Klarframe Scroll-Scrubbing Hintergrund — Einbau-Anleitung

Die "Frame verschlingt das Chaos"-Animation läuft als fixer Hintergrund und wird
frame-genau an die Scroll-Position gebunden: Scrollt man runter, saugt der
goldene Rahmen das Büro-Chaos auf — am Ende bleibt nur der glühende Frame.

## Was ist im Paket

```
scrub-frames/          → 150 WebP-Frames (frame_001.webp … frame_150.webp, ~6 MB gesamt)
FrameScrollBackground.jsx → fertige React-Component
ANLEITUNG.md           → diese Datei
```

## Schritt 1 — Frames auf den Server

Den kompletten Ordner `scrub-frames/` in dein `public/`-Verzeichnis kopieren:

```
public/
  scrub-frames/
    frame_001.webp
    ...
    frame_150.webp
```

(Bei Vite/anderen Setups: überall dort, wo statische Assets unter `/scrub-frames/...` erreichbar sind.)

## Schritt 2 — Component ins Projekt

`FrameScrollBackground.jsx` z.B. nach `components/` kopieren. Keine neuen
Dependencies nötig — nutzt nur `framer-motion`, das du schon installiert hast.

## Schritt 3 — Einbauen

Die Component wrappt den Bereich der Seite, über den die Animation laufen soll.
Alles, was als `children` reinkommt, scrollt ÜBER der Animation:

```jsx
import FrameScrollBackground from "@/components/FrameScrollBackground";

export default function Home() {
  return (
    <>
      <FrameScrollBackground scrollLength="400vh" overlayOpacity={0.55}>
        <HeroSection />
        <LeistungenSection />
        <StatsSection />
      </FrameScrollBackground>

      {/* Ab hier normaler Flow ohne Animation */}
      <ReferenzenSection />
      <Footer />
    </>
  );
}
```

## Die zwei Stellschrauben

| Prop | Bedeutung | Empfehlung |
|---|---|---|
| `scrollLength` | Wie viel Scroll-Strecke die Animation belegt. `"400vh"` = 4 Bildschirmhöhen scrollen für die volle Transformation. Länger = langsamer/entspannter. | 300–500vh |
| `overlayOpacity` | Dunkles Overlay über dem Video für Textlesbarkeit. | 0.45–0.65 |

## Zusammenspiel mit Lenis

Funktioniert out of the box mit deinem bestehenden Lenis-Setup — Lenis glättet
den Scroll, `useScroll` liest die geglättete Position, dadurch wirkt das
Scrubbing automatisch butterweich. Nichts weiter zu tun.

## Dramaturgie-Tipp

Die Animation hat drei Phasen — Content darauf abstimmen:

- **0–33% (chaotisches Büro):** Problem-Messaging („Zettelwirtschaft, manuelle Prozesse, Tool-Chaos…")
- **33–75% (Frame saugt alles ein):** Lösung („Klarframe automatisiert…")
- **75–100% (leerer Raum, glühender Frame):** Klarheit/CTA („Ein System. Klarheit.")

So erzählen Scroll, Bild und Text dieselbe Geschichte.

## Performance-Hinweise

- Frames sind 1280px breit / WebP q72 → ~40 KB pro Frame, 6 MB gesamt.
  Wird progressiv geladen: Rendering startet, sobald die ersten 15 Frames da sind.
- Canvas zeichnet nur bei Frame-Wechsel (nicht bei jedem Scroll-Event) via rAF.
- `devicePixelRatio` ist auf max. 2 gedeckelt (Retina scharf, ohne 3x-Kosten).
- Später 1080p-Version: einfach neue Frames mit gleichem Naming in den Ordner
  legen — Component bleibt unverändert.

## Mobile

Läuft auch auf Mobile. Wenn du dort sparen willst: per Media Query/JS auf
kleineren Screens nur jeden 2. Frame laden (FRAME_COUNT 75, Pfad-Funktion
anpassen) oder statisches Poster-Bild (frame_150) zeigen.

"use client";

/**
 * FrameScrollBackground — Klarframe Scroll-Scrubbing Hintergrund
 * ---------------------------------------------------------------
 * Spielt die 150 WebP-Frames der "Frame devours the room"-Animation
 * frame-genau an die Scroll-Position gebunden ab (Apple-Style).
 *
 * Funktionsweise:
 *  - Ein <canvas> liegt position:fixed hinter dem gesamten Content (zIndex 0)
 *  - Ein unsichtbarer "Scroll-Track" (height: 400vh) definiert, wie lange
 *    man scrollen muss, bis die Animation komplett durchgelaufen ist
 *  - useScroll + useTransform von Framer Motion mappen den Scroll-Fortschritt
 *    auf einen Frame-Index (0–149), der aufs Canvas gezeichnet wird
 *
 * Voraussetzungen: framer-motion (bereits installiert), Frames unter
 * /public/scrub-frames/frame_001.webp … frame_150.webp
 */

import { useEffect, useRef, useState, useCallback } from "react";
import { useScroll, useTransform, useMotionValueEvent } from "framer-motion";

const FRAME_COUNT = 150;
const FRAME_PATH = (i) =>
  `/scrub-frames/frame_${String(i + 1).padStart(3, "0")}.webp`;

export default function FrameScrollBackground({
  children,
  scrollLength = "400vh", // wie "lang" die Animation beim Scrollen ist
  overlayOpacity = 0.55,  // dunkles Overlay, damit Text lesbar bleibt
}) {
  const canvasRef = useRef(null);
  const trackRef = useRef(null);
  const imagesRef = useRef([]);
  const currentFrameRef = useRef(0);
  const [loaded, setLoaded] = useState(false);

  // ---- 1. Frames vorladen -------------------------------------------------
  useEffect(() => {
    let cancelled = false;
    let loadedCount = 0;
    const imgs = new Array(FRAME_COUNT);

    for (let i = 0; i < FRAME_COUNT; i++) {
      const img = new Image();
      img.src = FRAME_PATH(i);
      img.onload = () => {
        loadedCount++;
        // Sobald die ersten ~15 Frames da sind, schon rendern (schneller FCP),
        // Rest lädt im Hintergrund weiter
        if (!cancelled && loadedCount >= 15) setLoaded(true);
      };
      imgs[i] = img;
    }
    imagesRef.current = imgs;
    return () => {
      cancelled = true;
    };
  }, []);

  // ---- 2. Canvas-Größe an Viewport anpassen (mit devicePixelRatio) --------
  const resizeCanvas = useCallback(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    canvas.width = window.innerWidth * dpr;
    canvas.height = window.innerHeight * dpr;
    canvas.style.width = `${window.innerWidth}px`;
    canvas.style.height = `${window.innerHeight}px`;
    drawFrame(currentFrameRef.current);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    resizeCanvas();
    window.addEventListener("resize", resizeCanvas);
    return () => window.removeEventListener("resize", resizeCanvas);
  }, [resizeCanvas, loaded]);

  // ---- 3. Frame aufs Canvas zeichnen (cover-Verhalten wie CSS) ------------
  const drawFrame = useCallback((index) => {
    const canvas = canvasRef.current;
    const img = imagesRef.current[index];
    if (!canvas || !img || !img.complete || img.naturalWidth === 0) return;

    const ctx = canvas.getContext("2d");
    const cw = canvas.width;
    const ch = canvas.height;
    const iw = img.naturalWidth;
    const ih = img.naturalHeight;

    // object-fit: cover nachbauen
    const scale = Math.max(cw / iw, ch / ih);
    const dw = iw * scale;
    const dh = ih * scale;
    const dx = (cw - dw) / 2;
    const dy = (ch - dh) / 2;

    ctx.clearRect(0, 0, cw, ch);
    ctx.drawImage(img, dx, dy, dw, dh);
  }, []);

  // ---- 4. Scroll-Fortschritt → Frame-Index ---------------------------------
  const { scrollYProgress } = useScroll({
    target: trackRef,
    offset: ["start start", "end end"],
  });

  const frameIndex = useTransform(
    scrollYProgress,
    [0, 1],
    [0, FRAME_COUNT - 1]
  );

  useMotionValueEvent(frameIndex, "change", (latest) => {
    const idx = Math.min(FRAME_COUNT - 1, Math.max(0, Math.round(latest)));
    if (idx !== currentFrameRef.current) {
      currentFrameRef.current = idx;
      requestAnimationFrame(() => drawFrame(idx));
    }
  });

  // Ersten Frame zeichnen sobald geladen
  useEffect(() => {
    if (loaded) drawFrame(0);
  }, [loaded, drawFrame]);

  return (
    <div ref={trackRef} style={{ position: "relative", height: scrollLength }}>
      {/* Fixierter Hintergrund-Canvas */}
      <canvas
        ref={canvasRef}
        style={{
          position: "fixed",
          inset: 0,
          zIndex: 0,
          pointerEvents: "none",
          background: "#0e0e0e", // Klarframe-Anthrazit als Fallback
        }}
        aria-hidden="true"
      />

      {/* Dunkles Overlay für Textlesbarkeit */}
      <div
        style={{
          position: "fixed",
          inset: 0,
          zIndex: 1,
          pointerEvents: "none",
          background: `linear-gradient(
            to bottom,
            rgba(11,10,8,${overlayOpacity}) 0%,
            rgba(11,10,8,${overlayOpacity * 0.7}) 50%,
            rgba(11,10,8,${overlayOpacity}) 100%
          )`,
        }}
        aria-hidden="true"
      />

      {/* Scrollender Content über der Animation */}
      <div style={{ position: "relative", zIndex: 2 }}>{children}</div>
    </div>
  );
}

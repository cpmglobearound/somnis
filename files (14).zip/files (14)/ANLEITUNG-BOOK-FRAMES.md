# Klarframe Fantasy-Buch — TRANSPARENTE Frame-Sequenz · Anleitung für Claude Code

Schwebendes Zauberbuch: treibt herein → öffnet sich → Seiten blättern von vorne bis hinten →
schließt sich wieder. **Hintergrund ist transparent** (per KI-Matting freigestellt), das Buch
schwebt über jedem beliebigen Seitenhintergrund.

## Warum Frames statt Video?
Video-Modelle liefern kein echtes Alpha. Deshalb wurde der Hintergrund frame-weise entfernt und
als **transparente WebP-Frames** (Alphakanal) exportiert. Auf einem `<canvas>` gezeichnet bleibt
die Transparenz erhalten — funktioniert in allen Browsern (auch Safari/Mobile), anders als
transparente Videos.

## Inhalt
```
klarframe-book-frames/
├── frames/                  ← 181 TRANSPARENTE WebP-Frames (frame_0001.webp … frame_0181.webp)
├── FrameScrubBook.tsx       ← transparenter Canvas-Scrubber (object-fit: contain)
├── manifest.json
└── ANLEITUNG-BOOK-FRAMES.md
```

## Schritte
1. Inhalt von `frames/` → `public/klarframe-book/`
   (Pfade: `public/klarframe-book/frame_0001.webp` …).
2. `FrameScrubBook.tsx` → `components/hero/`.
3. Einbinden (Canvas ist clientseitig):
```tsx
import dynamic from "next/dynamic";
const FrameScrubBook = dynamic(() => import("@/components/hero/FrameScrubBook"), { ssr: false });

// Hintergrund kommt vom Eltern-Element — das Buch schwebt darüber:
<div style={{ background: "radial-gradient(circle at 50% 30%, #1a1410, #0a0a0a)" }}>
  <FrameScrubBook scrollLength="320vh" />
</div>
```

## Stellschrauben (Props)
- `scrollLength` — Höhe/Tempo der Scroll-Sektion. `"280vh"`–`"360vh"` testen.
- `frameCount` (181), `basePath`, `firstIndex`, `pad`, `ext` ("webp") — nur bei Umbenennung ändern.

## Eingebaut
- **Transparenz bleibt erhalten** (Canvas wird mit `clearRect` geleert, kein Hintergrund).
- `object-fit: contain` → das verzierte Buch wird nie angeschnitten.
- Preloader (%-Anzeige), Retina-Schärfe, rAF-gedrosselt.
- `prefers-reduced-motion` → zeigt statisch das aufgeschlagene Buch (ca. Frame 80).

## Tipp: Hintergrund frei wählbar
Da die Frames transparent sind, bestimmst du den Look über das Eltern-Element: dunkler
Verlauf, Pergament-Textur, ein Foto, oder einfach die Seitenfarbe. Das Buch passt sich an.

## Quelle / neu erzeugen
Original-Video (mit Hintergrund): `klarframe_book_fantasy_15s.mp4`.
Frames neu freistellen:
```
ffmpeg -i klarframe_book_fantasy_15s.mp4 -vf "fps=12,scale=1280:-1" -q:v 2 raw_%04d.jpg
rembg p <ordner_raw> <ordner_cut>          # KI-Matting -> transparente PNGs
for f in *.png; do cwebp -q 85 -alpha_q 90 "$f" -o "${f%.png}.webp"; done
```

"use client";

/**
 * FrameScrubBook — transparent floating-book scroll scrubber.
 *
 * Scrubs a TRANSPARENT image sequence (WebP/PNG with alpha) on a <canvas>, so the
 * book floats over whatever is behind it (page content, gradient, image — anything).
 * Forward scroll = book drifts in -> opens -> pages flip -> closes.
 *
 * SETUP
 * 1. Put frames in:  public/klarframe-book/frame_0001.webp ... frame_0181.webp
 * 2. App Router import (canvas is client-only):
 *      import dynamic from "next/dynamic";
 *      const FrameScrubBook = dynamic(() => import("@/components/hero/FrameScrubBook"), { ssr: false });
 * 3. Render <FrameScrubBook /> where the book section should be.
 *
 * Notes
 * - Background is TRANSPARENT on purpose. Put your own background on the parent/section.
 * - object-fit is "contain" so the ornate book is never cropped.
 */

import { useEffect, useRef, useState, useCallback } from "react";

type Props = {
  basePath?: string;
  frameCount?: number;
  firstIndex?: number;
  pad?: number;
  ext?: string;
  scrollLength?: string; // tempo. default "300vh"
};

export default function FrameScrubBook({
  basePath = "/klarframe-book/frame_",
  frameCount = 181,
  firstIndex = 1,
  pad = 4,
  ext = "webp",
  scrollLength = "300vh",
}: Props) {
  const sectionRef = useRef<HTMLElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const imagesRef = useRef<HTMLImageElement[]>([]);
  const currentFrame = useRef(-1);
  const rafPending = useRef(false);
  const [loaded, setLoaded] = useState(0);
  const [ready, setReady] = useState(false);

  const frameSrc = useCallback(
    (i: number) => `${basePath}${String(firstIndex + i).padStart(pad, "0")}.${ext}`,
    [basePath, firstIndex, pad, ext]
  );

  useEffect(() => {
    let done = 0;
    const imgs: HTMLImageElement[] = [];
    for (let i = 0; i < frameCount; i++) {
      const img = new Image();
      img.src = frameSrc(i);
      img.onload = img.onerror = () => {
        done++; setLoaded(done);
        if (done === frameCount) setReady(true);
      };
      imgs[i] = img;
    }
    imagesRef.current = imgs;
  }, [frameCount, frameSrc]);

  // draw with object-fit: contain, transparent clear
  const draw = useCallback((index: number) => {
    const canvas = canvasRef.current;
    const img = imagesRef.current[index];
    if (!canvas || !img || !img.complete || img.naturalWidth === 0) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    const cw = canvas.clientWidth, ch = canvas.clientHeight;
    if (canvas.width !== cw * dpr || canvas.height !== ch * dpr) {
      canvas.width = cw * dpr; canvas.height = ch * dpr;
    }
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    ctx.clearRect(0, 0, cw, ch); // keep transparency
    const ir = img.naturalWidth / img.naturalHeight, cr = cw / ch;
    let dw, dh;
    if (cr > ir) { dh = ch; dw = ch * ir; }   // contain
    else { dw = cw; dh = cw / ir; }
    const dx = (cw - dw) / 2, dy = (ch - dh) / 2;
    ctx.drawImage(img, dx, dy, dw, dh);
  }, []);

  useEffect(() => {
    if (!ready) return;
    const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    if (reduce) { draw(Math.round(frameCount * 0.45)); return; } // static "open book" frame

    const onScroll = () => {
      if (rafPending.current) return;
      rafPending.current = true;
      requestAnimationFrame(() => {
        rafPending.current = false;
        const el = sectionRef.current;
        if (!el) return;
        const rect = el.getBoundingClientRect();
        const total = el.offsetHeight - window.innerHeight;
        const progress = Math.min(1, Math.max(0, -rect.top / total));
        const frame = Math.min(frameCount - 1, Math.round(progress * (frameCount - 1)));
        if (frame !== currentFrame.current) { currentFrame.current = frame; draw(frame); }
      });
    };
    draw(0);
    window.addEventListener("scroll", onScroll, { passive: true });
    const onResize = () => draw(currentFrame.current < 0 ? 0 : currentFrame.current);
    window.addEventListener("resize", onResize);
    onScroll();
    return () => {
      window.removeEventListener("scroll", onScroll);
      window.removeEventListener("resize", onResize);
    };
  }, [ready, frameCount, draw]);

  const pct = Math.round((loaded / frameCount) * 100);

  return (
    <section ref={sectionRef} style={{ position: "relative", height: scrollLength }}>
      {/* Transparent sticky stage — put any background on the parent. */}
      <div style={{ position: "sticky", top: 0, height: "100vh", overflow: "hidden", background: "transparent" }}>
        <canvas ref={canvasRef} style={{ width: "100%", height: "100%", display: "block" }} />
        {!ready && (
          <div style={{ position: "absolute", inset: 0, display: "flex", alignItems: "center", justifyContent: "center", color: "var(--color-muted, #c9a96a)", fontSize: "0.8rem", letterSpacing: "0.15em" }}>
            {pct}%
          </div>
        )}
      </div>
    </section>
  );
}

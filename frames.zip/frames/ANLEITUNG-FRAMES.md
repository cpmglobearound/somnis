# Klarframe Scroll-Hero — Frame-Sequenz · Anleitung für Claude Code

Diese Sequenz ist der **„Apple-Stil"-Scroll-Hero**: statt ein Video zu scrubben (ruckelt
auf Safari/Mobile), zeichnen wir pro Scroll-Position ein Einzelbild auf ein `<canvas>`.
Zuverlässig, scharf, kontrollierbar.

## Inhalt dieses Pakets
```
klarframe-hero-frames/
├── frames/                  ← 181 Einzelbilder (frame_0001.jpg … frame_0181.jpg, 1280×720)
├── FrameScrubHero.tsx       ← fertige React/Next-Komponente (Canvas-Scrubber)
├── manifest.json            ← Metadaten (Frame-Anzahl, Pfadmuster …)
└── ANLEITUNG-FRAMES.md      ← dieses Dokument
```

## Schritt für Schritt

**1. Frames ablegen.** Den Inhalt von `frames/` nach `public/klarframe-hero/` kopieren, sodass
die Pfade so aussehen: `public/klarframe-hero/frame_0001.jpg` … `frame_0181.jpg`.

**2. Komponente einbinden.** `FrameScrubHero.tsx` nach `components/hero/` legen. Canvas läuft
nur clientseitig, deshalb im App-Router per dynamic import ohne SSR:
```tsx
import dynamic from "next/dynamic";
const FrameScrubHero = dynamic(() => import("@/components/hero/FrameScrubHero"), { ssr: false });

export default function Page() {
  return (
    <main>
      <FrameScrubHero />
      {/* … restliche Seite … */}
    </main>
  );
}
```

**3. Scroll-Tempo einstellen.** Über das Prop `scrollLength` (Default `"300vh"`). Größer =
langsamer, bedächtiger Scrub; kleiner = schneller. Für einen „mega" Hero ruhig `"400vh"`
testen. Die Komponente mappt die Scroll-Distanz der Sektion linear auf Frame 0 → 181.

## Die wichtigsten Stellschrauben (Props)
- `scrollLength` — Höhe der Scroll-Sektion (Tempo). Default `"300vh"`.
- `frameCount` — muss zur Dateianzahl passen (181).
- `basePath` / `firstIndex` / `pad` / `ext` — nur ändern, wenn du die Dateien umbenennst.

## Eingebaut (du musst nichts tun)
- **Preload + Ladeanzeige** (Prozent), damit beim Scrollen keine Lücken entstehen.
- **`object-fit: cover`** auf Canvas inkl. devicePixelRatio (scharf auf Retina).
- **`prefers-reduced-motion`** → zeigt statisch den **Endframe** (fertiger Mensch), keine Animation.
- **Headline-Overlay** bleibt echtes DOM (lesbar/zugänglich), liegt über dem Canvas.
- **rAF-gedrosselter Scroll-Handler** → flüssig, kein Layout-Thrash.

## Performance-Hinweise
- 181 JPGs ≈ **13 MB**. Für einen Hero okay, weil vorgeladen. Wenn es leichter sein soll:
  - In **WebP** wandeln (ca. halbe Größe):
    `for f in *.jpg; do cwebp -q 80 "$f" -o "${f%.jpg}.webp"; done` → dann `ext="webp"`.
  - Oder weniger Frames nehmen (z. B. jeden 2. → ~90 Frames). Smoothness vs. Gewicht abwägen.
- Optional: erste ~15 Frames mit `<link rel="preload">` priorisieren, damit Frame 0 sofort steht.
- Mobile: ggf. eine kleinere Frame-Variante (z. B. 720px breit) ausliefern.

## Alternative: GSAP statt nativem Scroll
Wenn ihr eh Lenis + GSAP nutzt (siehe `scroll-3d`-Skill), könnt ihr den Scroll-Handler durch
einen `ScrollTrigger` mit `scrub: true` ersetzen, der `onUpdate` den Frame-Index setzt und
`draw()` aufruft. Gleiches Ergebnis, aber konsistent mit der restlichen Scroll-Choreografie.

## Paste-Prompt für Claude Code
```
Binde components/hero/FrameScrubHero.tsx als Scroll-Hero ein. Kopiere die Frames nach
public/klarframe-hero/ (frame_0001.jpg … frame_0181.jpg). Importiere die Komponente per
next/dynamic mit ssr:false und rendere sie oben auf der Startseite. Setze scrollLength auf
"350vh". Stelle sicher, dass die Headline lesbar bleibt, der Preloader vor dem ersten Frame
angezeigt wird und prefers-reduced-motion den Endframe statisch zeigt. Danach build + kurzer
Testbericht (Ladezeit, Flüssigkeit beim Scrollen, Mobile).
```

## Wenn du die Quelle neu brauchst
Die Frames stammen aus `klarframe_assemble_TRON_15s.mp4` (15 s, 24 fps). Neu extrahieren mit
anderer Dichte/Größe:
```
ffmpeg -i klarframe_assemble_TRON_15s.mp4 -vf "fps=12,scale=1280:-1" -q:v 3 frame_%04d.jpg
```
(`fps` hoch = mehr Frames/smoother; `scale` = Breite.)

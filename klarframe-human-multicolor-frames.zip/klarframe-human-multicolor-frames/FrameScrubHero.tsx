"use client";

/**
 * FrameScrubHero — scroll-scrubbed image sequence (Apple AirPods style).
 *
 * Plays a frame sequence forward as the user scrolls down. More reliable than
 * scrubbing a <video> (especially on Safari/mobile). Renders to <canvas>.
 *
 * SETUP
 * 1. Put the frames in:  public/klarframe-hero/frame_0001.jpg ... frame_0181.jpg
 * 2. App Router import (canvas is client-only):
 *      import dynamic from "next/dynamic";
 *      const FrameScrubHero = dynamic(() => import("@/components/hero/FrameScrubHero"), { ssr: false });
 * 3. Render <FrameScrubHero /> at the top of the page.
 *
 * TUNING
 * - scrollLength controls how much scrolling maps to the full animation.
 *   Higher = slower, more deliberate scrub. "300vh" is a good start.
 * - frameCount / basePath / firstIndex must match your files.
 */

import { useEffect, useRef, useState, useCallback } from "react";

type Props = {
  basePath?: string;     // folder + file prefix
  frameCount?: number;
  firstIndex?: number;
  pad?: number;          // zero-padding digits (frame_0001 -> 4)
  ext?: string;
  scrollLength?: string; // e.g. "300vh" — length of the scrubbable section
};

export default function FrameScrubHero({
  basePath = "/klarframe-hero/frame_",
  frameCount = 181,
  firstIndex = 1,
  pad = 4,
  ext = "jpg",
  scrollLength = "300vh",
}: Props) {
  const sectionRef = useRef<HTMLElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const imagesRef = useRef<HTMLImageElement[]>([]);
  const currentFrame = useRef(0);
  const rafPending = useRef(false);
  const [loaded, setLoaded] = useState(0);
  const [ready, setReady] = useState(false);

  const frameSrc = useCallback(
    (i: number) =>
      `${basePath}${String(firstIndex + i).padStart(pad, "0")}.${ext}`,
    [basePath, firstIndex, pad, ext]
  );

  // Preload all frames
  useEffect(() => {
    let done = 0;
    const imgs: HTMLImageElement[] = [];
    for (let i = 0; i < frameCount; i++) {
      const img = new Image();
      img.src = frameSrc(i);
      img.onload = img.onerror = () => {
        done++;
        setLoaded(done);
        if (done === frameCount) setReady(true);
      };
      imgs[i] = img;
    }
    imagesRef.current = imgs;
  }, [frameCount, frameSrc]);

  // Draw a frame, object-fit: cover
  const draw = useCallback((index: number) => {
    const canvas = canvasRef.current;
    const img = imagesRef.current[index];
    if (!canvas || !img || !img.complete || img.naturalWidth === 0) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    const cw = canvas.clientWidth;
    const ch = canvas.clientHeight;
    if (canvas.width !== cw * dpr || canvas.height !== ch * dpr) {
      canvas.width = cw * dpr;
      canvas.height = ch * dpr;
    }
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);

    const ir = img.naturalWidth / img.naturalHeight;
    const cr = cw / ch;
    let dw = cw, dh = ch, dx = 0, dy = 0;
    if (cr > ir) { dh = cw / ir; dy = (ch - dh) / 2; }
    else { dw = ch * ir; dx = (cw - dw) / 2; }
    ctx.clearRect(0, 0, cw, ch);
    ctx.drawImage(img, dx, dy, dw, dh);
  }, []);

  // Scroll -> frame mapping
  useEffect(() => {
    if (!ready) return;
    const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    if (reduce) { draw(frameCount - 1); return; } // static final frame

    const onScroll = () => {
      if (rafPending.current) return;
      rafPending.current = true;
      requestAnimationFrame(() => {
        rafPending.current = false;
        const el = sectionRef.current;
        if (!el) return;
        const rect = el.getBoundingClientRect();
        const total = el.offsetHeight - window.innerHeight;
        const progress = Math.min(1, Math.max(0, -rect.top / total));
        const frame = Math.min(frameCount - 1, Math.round(progress * (frameCount - 1)));
        if (frame !== currentFrame.current) {
          currentFrame.current = frame;
          draw(frame);
        }
      });
    };

    draw(0);
    window.addEventListener("scroll", onScroll, { passive: true });
    window.addEventListener("resize", () => draw(currentFrame.current));
    return () => window.removeEventListener("scroll", onScroll);
  }, [ready, frameCount, draw]);

  const pct = Math.round((loaded / frameCount) * 100);

  return (
    <section ref={sectionRef} style={{ position: "relative", height: scrollLength }}>
      <div
        style={{
          position: "sticky",
          top: 0,
          height: "100vh",
          overflow: "hidden",
          background: "var(--color-bg, #0a0a0a)",
        }}
      >
        <canvas
          ref={canvasRef}
          style={{ width: "100%", height: "100%", display: "block" }}
        />

        {/* Loading state */}
        {!ready && (
          <div
            style={{
              position: "absolute",
              inset: 0,
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              color: "var(--color-muted, #c9a96a)",
              fontSize: "0.8rem",
              letterSpacing: "0.15em",
            }}
          >
            {pct}%
          </div>
        )}

        {/* Headline overlay (kept in DOM for accessibility) */}
        <div
          style={{
            position: "absolute",
            inset: 0,
            display: "flex",
            flexDirection: "column",
            alignItems: "center",
            justifyContent: "center",
            textAlign: "center",
            pointerEvents: "none",
            padding: "0 1.5rem",
          }}
        >
          <h1
            style={{
              color: "var(--color-fg, #f4ecdd)",
              fontFamily: "var(--font-display, inherit)",
              fontSize: "clamp(2rem, 6vw, 4.5rem)",
              lineHeight: 1.05,
              maxWidth: "18ch",
              margin: 0,
              textShadow: "0 2px 30px rgba(0,0,0,0.5)",
            }}
          >
            Nicht noch ein Tool — ein System, das mit Ihnen wächst.
          </h1>
        </div>
      </div>
    </section>
  );
}

"use client";

/**
 * FrameScrubJourney — frame-sequence scroll scrubber with a downward parallax drift.
 *
 * Same as FrameScrubHero, but the canvas also translates slightly DOWNWARD as you
 * scroll, so the scene feels like it "travels down the page" with you (on top of the
 * downward camera crane already baked into the clip). Tuned for the abstract
 * "face -> strands flow down -> network forms below" journey.
 *
 * SETUP
 * 1. Put frames in:  public/klarframe-journey/frame_0001.jpg ... frame_0181.jpg
 * 2. App Router import (client-only):
 *      import dynamic from "next/dynamic";
 *      const FrameScrubJourney = dynamic(() => import("@/components/hero/FrameScrubJourney"), { ssr: false });
 * 3. Render <FrameScrubJourney /> where the journey section should be.
 */

import { useEffect, useRef, useState, useCallback } from "react";

type Props = {
  basePath?: string;
  frameCount?: number;
  firstIndex?: number;
  pad?: number;
  ext?: string;
  scrollLength?: string; // length of the scrubbable section (tempo). default "400vh"
  parallaxVh?: number;   // how far the scene drifts down across the scroll (in vh). 0 = off
};

export default function FrameScrubJourney({
  basePath = "/klarframe-journey/frame_",
  frameCount = 181,
  firstIndex = 1,
  pad = 4,
  ext = "jpg",
  scrollLength = "400vh",
  parallaxVh = 8,
}: Props) {
  const sectionRef = useRef<HTMLElement>(null);
  const stageRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const imagesRef = useRef<HTMLImageElement[]>([]);
  const currentFrame = useRef(-1);
  const rafPending = useRef(false);
  const [loaded, setLoaded] = useState(0);
  const [ready, setReady] = useState(false);

  const frameSrc = useCallback(
    (i: number) => `${basePath}${String(firstIndex + i).padStart(pad, "0")}.${ext}`,
    [basePath, firstIndex, pad, ext]
  );

  useEffect(() => {
    let done = 0;
    const imgs: HTMLImageElement[] = [];
    for (let i = 0; i < frameCount; i++) {
      const img = new Image();
      img.src = frameSrc(i);
      img.onload = img.onerror = () => {
        done++; setLoaded(done);
        if (done === frameCount) setReady(true);
      };
      imgs[i] = img;
    }
    imagesRef.current = imgs;
  }, [frameCount, frameSrc]);

  const draw = useCallback((index: number) => {
    const canvas = canvasRef.current;
    const img = imagesRef.current[index];
    if (!canvas || !img || !img.complete || img.naturalWidth === 0) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    const cw = canvas.clientWidth, ch = canvas.clientHeight;
    if (canvas.width !== cw * dpr || canvas.height !== ch * dpr) {
      canvas.width = cw * dpr; canvas.height = ch * dpr;
    }
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    const ir = img.naturalWidth / img.naturalHeight, cr = cw / ch;
    let dw = cw, dh = ch, dx = 0, dy = 0;
    if (cr > ir) { dh = cw / ir; dy = (ch - dh) / 2; }
    else { dw = ch * ir; dx = (cw - dw) / 2; }
    ctx.clearRect(0, 0, cw, ch);
    ctx.drawImage(img, dx, dy, dw, dh);
  }, []);

  useEffect(() => {
    if (!ready) return;
    const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    if (reduce) { draw(frameCount - 1); return; }

    const onScroll = () => {
      if (rafPending.current) return;
      rafPending.current = true;
      requestAnimationFrame(() => {
        rafPending.current = false;
        const el = sectionRef.current, stage = stageRef.current;
        if (!el || !stage) return;
        const rect = el.getBoundingClientRect();
        const total = el.offsetHeight - window.innerHeight;
        const progress = Math.min(1, Math.max(0, -rect.top / total));
        // frame
        const frame = Math.min(frameCount - 1, Math.round(progress * (frameCount - 1)));
        if (frame !== currentFrame.current) { currentFrame.current = frame; draw(frame); }
        // parallax downward drift
        stage.style.transform = `translateY(${progress * parallaxVh}vh)`;
      });
    };

    draw(0);
    window.addEventListener("scroll", onScroll, { passive: true });
    const onResize = () => draw(currentFrame.current < 0 ? 0 : currentFrame.current);
    window.addEventListener("resize", onResize);
    onScroll();
    return () => {
      window.removeEventListener("scroll", onScroll);
      window.removeEventListener("resize", onResize);
    };
  }, [ready, frameCount, draw, parallaxVh]);

  const pct = Math.round((loaded / frameCount) * 100);

  return (
    <section ref={sectionRef} style={{ position: "relative", height: scrollLength }}>
      <div style={{ position: "sticky", top: 0, height: "100vh", overflow: "hidden", background: "var(--color-bg, #0a0a0a)" }}>
        {/* stage is slightly oversized so the parallax drift never reveals gaps */}
        <div
          ref={stageRef}
          style={{ position: "absolute", left: 0, top: `-${parallaxVh}vh`, width: "100%", height: `calc(100% + ${parallaxVh * 2}vh)`, willChange: "transform" }}
        >
          <canvas ref={canvasRef} style={{ width: "100%", height: "100%", display: "block" }} />
        </div>

        {!ready && (
          <div style={{ position: "absolute", inset: 0, display: "flex", alignItems: "center", justifyContent: "center", color: "var(--color-muted, #c9a96a)", fontSize: "0.8rem", letterSpacing: "0.15em" }}>
            {pct}%
          </div>
        )}

        <div style={{ position: "absolute", inset: 0, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", textAlign: "center", pointerEvents: "none", padding: "0 1.5rem" }}>
          <h1 style={{ color: "var(--color-fg, #f4ecdd)", fontFamily: "var(--font-display, inherit)", fontSize: "clamp(2rem, 6vw, 4.5rem)", lineHeight: 1.05, maxWidth: "18ch", margin: 0, textShadow: "0 2px 30px rgba(0,0,0,0.5)" }}>
            Vom Menschen zum System.
          </h1>
        </div>
      </div>
    </section>
  );
}

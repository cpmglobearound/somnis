# Klarframe Abwärts-Reise (Mensch, mehrfarbig) — Frame-Sequenz · Anleitung für Claude Code

Abstrakter Abwärts-Hero mit **echtem Menschen** und **mehrfarbiger** Palette: oben setzt sich
ein fotorealistisches Gesicht aus bunten Partikeln zusammen, farbige Stränge fahren nach unten
heraus, die Kamera fährt mit, unten formt sich daraus ein mehrfarbiges Netz-Gitter.

## Inhalt
```
klarframe-human-multicolor-frames/
├── frames/                  ← 181 Frames (frame_0001.jpg … frame_0181.jpg, 1280×720)
├── FrameScrubJourney.tsx    ← Scrubber MIT Parallax-Abwärtsdrift (empfohlen)
├── FrameScrubHero.tsx       ← schlichter Scrubber ohne Parallax (Alternative)
├── manifest.json
└── ANLEITUNG-FRAMES.md
```

## Schritte
1. Inhalt von `frames/` → `public/klarframe-journey/` (Pfade: `public/klarframe-journey/frame_0001.jpg` …).
   (Wenn du den Gold-Clip schon dort liegen hast: anderen Ordner nehmen, z. B. `public/klarframe-journey-color/`, und im Prop `basePath="/klarframe-journey-color/frame_"` setzen.)
2. `FrameScrubJourney.tsx` → `components/hero/`.
3. Einbinden (Canvas ist clientseitig):
```tsx
import dynamic from "next/dynamic";
const FrameScrubJourney = dynamic(() => import("@/components/hero/FrameScrubJourney"), { ssr: false });
// ...
<FrameScrubJourney scrollLength="500vh" parallaxVh={8} />
```

## Stellschrauben (Props)
- `scrollLength` — Höhe/Tempo. Für die lange Reise `"450vh"`–`"550vh"`.
- `parallaxVh` — zusätzliche Abwärtsdrift beim Scrollen (vh). `8` dezent, `0` = aus.
- `basePath` — anpassen, falls du einen anderen Ordnernamen nutzt.
- `frameCount` (181), `firstIndex`, `pad`, `ext` — nur bei Umbenennung ändern.

## Eingebaut
Preloader (%-Anzeige), `object-fit: cover` + Retina-Schärfe, `prefers-reduced-motion` →
statischer Endframe (das Netz), Headline-Overlay als echtes DOM, rAF-gedrosselt, Stage leicht
überdimensioniert (Parallax erzeugt keine Ränder).

## Performance
181 JPGs ≈ 17 MB. Leichter via WebP:
`for f in *.jpg; do cwebp -q 80 "$f" -o "${f%.jpg}.webp"; done`  → dann `ext="webp"`.

## Paste-Prompt für Claude Code
```
Kopiere die Frames nach public/klarframe-journey/ (frame_0001.jpg … frame_0181.jpg) und binde
components/hero/FrameScrubJourney.tsx per next/dynamic (ssr:false) als Scroll-Sektion ein.
Setze scrollLength="500vh" und parallaxVh={8}. Headline lesbar halten, Preloader vor dem ersten
Frame zeigen, prefers-reduced-motion -> Endframe statisch. Danach build + Testbericht.
```

## Quelle neu extrahieren (dichter / andere Größe)
```
ffmpeg -i klarframe_journey_human_multicolor_15s.mp4 -vf "fps=12,scale=1280:-1" -q:v 3 frame_%04d.jpg
```

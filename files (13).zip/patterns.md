# scroll-3d — Patterns

Copy-ready patterns. Adapt imports to the project's router/version. All identifiers
in English; keep them as-is.

---

## 1. Lenis + GSAP coupling (the foundation)

The single most common bug is Lenis and ScrollTrigger running on different clocks.
Drive ScrollTrigger from Lenis and run Lenis off the GSAP ticker.

```tsx
"use client";
import { useEffect } from "react";
import Lenis from "lenis";
import { gsap } from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";

gsap.registerPlugin(ScrollTrigger);

export function useSmoothScroll() {
  useEffect(() => {
    const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    if (reduce) return; // native scroll, no smoothing

    const lenis = new Lenis({ duration: 1.1, smoothWheel: true });

    lenis.on("scroll", ScrollTrigger.update);
    const raf = (time: number) => lenis.raf(time * 1000);
    gsap.ticker.add(raf);
    gsap.ticker.lagSmoothing(0);

    return () => {
      gsap.ticker.remove(raf);
      lenis.destroy();
    };
  }, []);
}
```

Call `useSmoothScroll()` once near the top of the App Router layout (in a small
`"use client"` provider). Don't instantiate Lenis more than once.

---

## 2. Reveal on scroll (staggered) — for service cards, lists

```tsx
"use client";
import { useEffect, useRef } from "react";
import { gsap } from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
gsap.registerPlugin(ScrollTrigger);

export function useReveal(selector: string) {
  const scope = useRef<HTMLElement>(null);
  useEffect(() => {
    if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;
    const ctx = gsap.context(() => {
      gsap.from(selector, {
        y: 24, autoAlpha: 0, duration: 0.6, ease: "power2.out",
        stagger: 0.08,
        scrollTrigger: { trigger: scope.current, start: "top 75%" },
      });
    }, scope);
    return () => ctx.revert(); // kills triggers + restores styles
  }, [selector]);
  return scope;
}
```

`gsap.context(...).revert()` is the clean-up. Always use it.

---

## 3. Pin + scrub (before/after, journey steps)

```tsx
const ctx = gsap.context(() => {
  const tl = gsap.timeline({
    scrollTrigger: {
      trigger: sectionRef.current,
      start: "top top",
      end: "+=120%",       // length of the pinned scroll
      pin: true,
      scrub: 1,            // ties timeline progress to scroll
      anticipatePin: 1,
    },
  });
  tl.to(".state-before", { autoAlpha: 0, duration: 0.5 })
    .from(".state-after", { autoAlpha: 0, duration: 0.5 }, "<");
}, sectionRef);
```

Reserve the section height so pinning doesn't cause layout shift.

---

## 4. Count-up stat counters

```tsx
ScrollTrigger.create({
  trigger: el, start: "top 80%", once: true,
  onEnter: () => {
    const obj = { v: 0 };
    gsap.to(obj, { v: target, duration: 1.2, ease: "power1.out",
      onUpdate: () => { el.textContent = Math.round(obj.v).toString(); } });
  },
});
```

For non-numeric stats ("∞", "Alle") leave them static.

---

## 5. R3F scene driven by page scroll

Two valid approaches:

**(a) drei `ScrollControls`** — when the whole experience is inside one canvas.
**(b) external scroll progress** — when integrating a canvas into a normal content page
(Klarframe's case). Drive a uniform/ref from ScrollTrigger:

```tsx
// progress.ts — shared 0..1 scroll progress for one section
import { useEffect } from "react";
import { gsap } from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
gsap.registerPlugin(ScrollTrigger);

export function useSectionProgress(
  ref: React.RefObject<HTMLElement>,
  onProgress: (p: number) => void
) {
  useEffect(() => {
    const st = ScrollTrigger.create({
      trigger: ref.current, start: "top top", end: "bottom bottom",
      scrub: true, onUpdate: (self) => onProgress(self.progress),
    });
    return () => st.kill();
  }, [ref, onProgress]);
}
```

Inside the canvas, read the latest progress from a ref in `useFrame` (never set React
state every frame — that re-renders):

```tsx
import { useFrame } from "@react-three/fiber";
const progress = useRef(0);            // updated by onProgress above
useFrame(() => { /* use progress.current to lerp positions/camera */ });
```

---

## 6. Performance & accessibility checklist

- `<Canvas frameloop="demand" dpr={[1, 2]}>` and `invalidate()` on change, OR pause via
  IntersectionObserver when the hero leaves the viewport.
- Cap device pixel ratio (`dpr={[1, 1.5]}` on mobile).
- Reduce particle/instance count on small screens (`window.innerWidth < 768`).
- `prefers-reduced-motion` → render the **final composed state** statically, no animation.
- No-WebGL → render a static fallback image instead of the Canvas.
- Lazy-load the hero: `const Hero = dynamic(() => import("..."), { ssr: false });`
- Keep DOM text (headline) outside the canvas so it stays selectable and accessible.

---

## 7. Bringing in a real GLB model (later veneer)

```bash
npx gltfjsx@latest public/models/system.glb --types
# → generates a <System /> React component with typed nodes you can animate
```

Load with drei: `useGLTF("/models/system.glb")` and `<Preload all />`. Compress with
draco/meshopt if the file is large. Only do this after the procedural hero is solid.

---

## 8. Anti-patterns (do not do)

- Setting React state inside `useFrame` (kills performance).
- Multiple Lenis instances; Lenis without GSAP coupling.
- ScrollTriggers without `.kill()` / `ctx.revert()` (leaks on route change).
- Scrubbing a `<video>` as the primary hero on mobile (Safari janks) — use image sequence.
- Neon, glitch, "BOOM" — off-brand. Stop and reconsider.

"use client";

/**
 * SystemField — Klarframe signature hero.
 *
 * Motif: chaos -> order. A scattered cloud of points assembles into a clean
 * wireframe "frame" as the user scrolls. Procedural (no external asset needed).
 *
 * Integration (App Router):
 *   import dynamic from "next/dynamic";
 *   const SystemFieldHero = dynamic(() => import("@/components/hero/SystemField"), { ssr: false });
 *   ...then render <SystemFieldHero /> at the top of the page.
 *
 * Requires: three, @react-three/fiber. Optional: @react-three/drei (not used here).
 * Reads brand colors from CSS variables --color-bg / --color-fg / --color-accent
 * with safe fallbacks. Replace fallbacks or rely on the real tokens.
 */

import { useEffect, useMemo, useRef, useState } from "react";
import { Canvas, useFrame } from "@react-three/fiber";
import * as THREE from "three";
import { gsap } from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";

gsap.registerPlugin(ScrollTrigger);

const COUNT_DESKTOP = 2600;
const COUNT_MOBILE = 1000;
const FRAME_SIZE = 3.2;

// Distribute N points along the 12 edges of a cube -> reads as a "frame".
function buildFramePositions(n: number, size: number): Float32Array {
  const h = size / 2;
  const corners: [number, number, number][] = [
    [-h, -h, -h], [h, -h, -h], [h, h, -h], [-h, h, -h],
    [-h, -h, h], [h, -h, h], [h, h, h], [-h, h, h],
  ];
  const edges: [number, number][] = [
    [0, 1], [1, 2], [2, 3], [3, 0],
    [4, 5], [5, 6], [6, 7], [7, 4],
    [0, 4], [1, 5], [2, 6], [3, 7],
  ];
  const out = new Float32Array(n * 3);
  for (let i = 0; i < n; i++) {
    const e = edges[i % edges.length];
    const t = Math.random();
    const a = corners[e[0]];
    const b = corners[e[1]];
    out[i * 3 + 0] = a[0] + (b[0] - a[0]) * t;
    out[i * 3 + 1] = a[1] + (b[1] - a[1]) * t;
    out[i * 3 + 2] = a[2] + (b[2] - a[2]) * t;
  }
  return out;
}

// Random points in a sphere -> the "chaos" start state.
function buildCloudPositions(n: number, radius: number): Float32Array {
  const out = new Float32Array(n * 3);
  for (let i = 0; i < n; i++) {
    const r = radius * Math.cbrt(Math.random());
    const theta = Math.random() * Math.PI * 2;
    const phi = Math.acos(2 * Math.random() - 1);
    out[i * 3 + 0] = r * Math.sin(phi) * Math.cos(theta);
    out[i * 3 + 1] = r * Math.sin(phi) * Math.sin(theta);
    out[i * 3 + 2] = r * Math.cos(phi);
  }
  return out;
}

function readVar(name: string, fallback: string): string {
  if (typeof window === "undefined") return fallback;
  const v = getComputedStyle(document.documentElement).getPropertyValue(name).trim();
  return v || fallback;
}

function PointsField({
  count,
  progressRef,
}: {
  count: number;
  progressRef: React.MutableRefObject<number>;
}) {
  const ref = useRef<THREE.Points>(null);
  const cloud = useMemo(() => buildCloudPositions(count, 4.2), [count]);
  const frame = useMemo(() => buildFramePositions(count, FRAME_SIZE), [count]);
  // live buffer we mutate each frame; initialized from the current progress so
  // the static (reduced-motion, progress=1) end-state paints correctly on mount.
  const positions = useMemo(() => {
    const arr = cloud.slice();
    const p = progressRef.current;
    const e = p * p * (3 - 2 * p);
    for (let i = 0; i < arr.length; i++) arr[i] = cloud[i] + (frame[i] - cloud[i]) * e;
    return arr;
  }, [cloud, frame, progressRef]);

  const color = useMemo(
    () => new THREE.Color(readVar("--color-accent", "#8aa6c8")),
    []
  );

  useFrame((_, delta) => {
    const p = progressRef.current; // 0..1
    // ease the assembly so it settles cleanly
    const e = p * p * (3 - 2 * p); // smoothstep
    for (let i = 0; i < count * 3; i++) {
      positions[i] = cloud[i] + (frame[i] - cloud[i]) * e;
    }
    const geo = ref.current?.geometry as THREE.BufferGeometry | undefined;
    if (geo) {
      (geo.attributes.position as THREE.BufferAttribute).needsUpdate = true;
    }
    if (ref.current) {
      // slow drift; near-still once assembled
      ref.current.rotation.y += delta * (0.12 * (1 - e) + 0.02);
    }
  });

  return (
    <points ref={ref}>
      <bufferGeometry>
        <bufferAttribute
          attach="attributes-position"
          array={positions}
          count={count}
          itemSize={3}
        />
      </bufferGeometry>
      <pointsMaterial
        size={0.02}
        sizeAttenuation
        color={color}
        transparent
        opacity={0.9}
        depthWrite={false}
      />
    </points>
  );
}

export default function SystemFieldHero() {
  const sectionRef = useRef<HTMLElement>(null);
  const progressRef = useRef(0);
  const [count, setCount] = useState(COUNT_DESKTOP);
  const [enabled, setEnabled] = useState(true);

  useEffect(() => {
    const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    const mobile = window.innerWidth < 768;
    setCount(mobile ? COUNT_MOBILE : COUNT_DESKTOP);

    if (reduce) {
      // Respect reduced motion: show the assembled end-state, no scroll animation.
      progressRef.current = 1;
      setEnabled(false);
      return;
    }

    const st = ScrollTrigger.create({
      trigger: sectionRef.current,
      start: "top top",
      end: "bottom bottom",
      scrub: true,
      onUpdate: (self) => {
        progressRef.current = self.progress;
      },
    });
    return () => st.kill();
  }, []);

  return (
    // Tall section: the inner canvas is sticky, scroll drives the assembly.
    <section
      ref={sectionRef}
      style={{ position: "relative", height: "220vh" }}
      aria-label="Klarframe — ein System aus vielen Teilen"
    >
      <div
        style={{
          position: "sticky",
          top: 0,
          height: "100vh",
          overflow: "hidden",
          background: "var(--color-bg, #0b0e13)",
        }}
      >
        <Canvas
          camera={{ position: [0, 0, 8], fov: 45 }}
          dpr={[1, typeof window !== "undefined" && window.innerWidth < 768 ? 1.5 : 2]}
          gl={{ antialias: true, alpha: true }}
          frameloop={enabled ? "always" : "demand"}
        >
          <PointsField count={count} progressRef={progressRef} />
        </Canvas>

        {/* Headline stays in the DOM: accessible, selectable, high-contrast. */}
        <div
          style={{
            position: "absolute",
            inset: 0,
            display: "flex",
            flexDirection: "column",
            alignItems: "center",
            justifyContent: "center",
            textAlign: "center",
            pointerEvents: "none",
            padding: "0 1.5rem",
          }}
        >
          <p
            style={{
              letterSpacing: "0.18em",
              textTransform: "uppercase",
              fontSize: "0.8rem",
              color: "var(--color-muted, #9aa7b8)",
              margin: 0,
            }}
          >
            KI-Partner für nachhaltig wachsende Unternehmen
          </p>
          <h1
            style={{
              fontFamily: "var(--font-display, inherit)",
              color: "var(--color-fg, #f2f5f9)",
              fontSize: "clamp(2rem, 6vw, 4.5rem)",
              lineHeight: 1.05,
              maxWidth: "18ch",
              margin: "0.75rem 0 0",
            }}
          >
            Nicht noch ein Tool — ein System, das mit Ihnen wächst.
          </h1>
        </div>
      </div>
    </section>
  );
}

# CLAUDE.md — Klarframe Web Experience

Project memory for Claude Code. Read this first, every session.

## What this project is
Klarframe is a calm, premium B2B agency site (Next.js, multilingual de/en/es) selling
holistic AI systems, voice agents, automation, dashboards. Service #10 is **"Interactive
Web Experiences"** — so this site must itself *demonstrate* that capability.

## Brand doctrine (non-negotiable)
- Voice: **calm, clear, serious, anti-noise.** Tagline spirit: "Not another tool — one
  system that grows with you." The brand literally says "we are not here to make more noise."
- Therefore: **one perfect signature 3D moment + restrained scroll choreography everywhere
  else.** Restraint IS the statement.
- Forbidden: loud "AI-reel" aesthetics — glitch portraits, neon/cyberpunk, "BOOM" energy,
  effects with no message behind them.
- Core motif for ALL motion: **chaos → order.** Scattered points assemble into one clean,
  connected structure (a "frame") on scroll = the whole brand message in one move.

## Tech baseline
- Framework: Next.js (CONFIRM router + version on first run).
- Detect React version before installing R3F: **fiber v9 + drei v10 for React 19 / Next 15**;
  **fiber v8 for React 18.**
- Animation stack: `lenis` (smooth scroll) + `gsap` ScrollTrigger (choreography) +
  `three` / `@react-three/fiber` / `@react-three/drei` (signature hero only).
- R3F is client-only: `"use client"` + `next/dynamic({ ssr: false })`.

## Design tokens — REPLACE with real values extracted from globals.css / tailwind.config
> Do not invent. Read the existing theme on first run and overwrite this block.
```
--color-bg:        #__   /* base background (calm, near-monochrome) */
--color-fg:        #__   /* primary text */
--color-muted:     #__   /* secondary text / lines */
--color-accent:    #__   /* SINGLE restrained accent — no neon */
--font-display:    "__"
--font-body:       "__"
--radius:          __px
--max-content:     __px
```

## Hard rules
1. Branch `feature/scroll-experience`. Never commit to `main`. No major dep upgrades w/o asking.
2. Integrate into the existing Next.js/Tailwind setup — do not introduce a new framework/UI lib.
3. Respect `prefers-reduced-motion` everywhere (disable Lenis, fall back to static end-state).
4. Never break i18n (de/en/es) or anchor navigation (#services, #journey, #process, #contact).
5. Always clean up ScrollTriggers + Lenis on unmount (no leaks on route change).
6. Provide a non-WebGL fallback (static hero image) and a no-JS-safe content baseline.
7. Phase-gate: audit → smooth scroll → choreography → signature hero → polish. Build + verify
   after each phase before moving on.

## Known issue to fix
`og:image` / `twitter:image` point to `http://localhost:3000/klarframe.png` →
must be `https://klarframe.com/klarframe.png`. Broken social-share preview otherwise.

## How to use the skill
The `scroll-3d` skill (in `.claude/skills/scroll-3d/`) holds the reproducible recipe and the
code patterns in its `references/patterns.md`. Apply it for any scroll/3D work here.

## Optional MCP assets
Higgsfield MCP (`generate_3d` → GLB, `generate_video` → scrub clips) and Figma MCP (design
reference) may be configured. The starter hero needs no external asset (procedural points).

---
name: scroll-3d
description: >-
  Build calm, premium scroll-driven motion and WebGL 3D for the Klarframe site.
  Use this whenever the task involves smooth scrolling, GSAP ScrollTrigger
  choreography, pinned/sticky sections, scroll-scrubbed media, or React Three
  Fiber (three.js) scenes tied to scroll. Enforces the brand doctrine (restraint,
  the chaos→order motif), correct Lenis+GSAP coupling, accessibility, and
  performance. Read references/patterns.md for the concrete code patterns.
---

# scroll-3d

Reproducible recipe for scroll & 3D work on Klarframe. The goal is a single
signature 3D moment plus restrained choreography — never a reel-style effect zoo.

## When to use
Smooth scroll, scroll-linked animation, pinned sections, counters, reveal-on-scroll,
scroll-scrubbed video, or any three.js / React Three Fiber scene driven by scroll.

## Decision: which technique?
1. **Just need it to feel premium / fade & move on scroll?** → Lenis + GSAP ScrollTrigger.
   No 3D. This is the default for 90% of sections.
2. **A signature, alive, reactive moment (the hero, the "system" graph)?** → React Three
   Fiber. Real geometry, real depth. Use sparingly — it costs performance.
3. **A pre-rendered cinematic clip that should "play on scroll"?** → scroll-scrubbed video
   or image-sequence canvas. Accent only, never the leitmotif. Mobile Safari scrubs video
   poorly → prefer an image sequence for anything critical.

If unsure, choose the cheaper option (1 before 2 before 3).

## Brand guardrails (apply to every effect)
- Calm, clear, serious. Short distances, soft easings (`power2.out`), nothing "springs".
- One restrained accent color from the tokens. No neon, no glitch, no cyberpunk.
- Every motion should serve the **chaos → order / "one system"** motif or be cut.
- If a reviewer could say "this looks like an AI reel", it's wrong — redo it.

## Mandatory technical rules
- **Couple Lenis and GSAP** or they desync (see patterns.md → "Lenis + GSAP").
- **Respect `prefers-reduced-motion`**: skip Lenis, render static end-states, no scrubbing.
- **R3F is client-only**: `"use client"` + `next/dynamic({ ssr: false })`.
- **Match versions to React**: fiber v9/drei v10 for React 19; fiber v8 for React 18.
- **Clean up** every ScrollTrigger and the Lenis instance on unmount.
- **Pause offscreen**: `frameloop="demand"` or IntersectionObserver so the canvas isn't
  burning frames when not visible.
- **Provide fallbacks**: no-WebGL → static image; reduced-motion → static composed state.
- **No layout shift**: reserve heights for pinned/sticky sections.

## Workflow
1. Read `CLAUDE.md` for the real design tokens (never invent colors).
2. Pick the technique via the decision list above.
3. Implement using the matching pattern in `references/patterns.md`.
4. Build, verify in-browser (desktop + a throttled mobile profile), check reduced-motion.
5. Confirm cleanup and offscreen pausing. Commit on `feature/scroll-experience`.

## Files
- `references/patterns.md` — copy-ready patterns: Lenis+GSAP coupling, reveal/stagger,
  pin + scrub, counter, R3F scroll progress wiring, perf & a11y, GLB via gltfjsx.
- The starter signature hero lives at `components/hero/SystemField.tsx` (procedural points,
  no external asset required).

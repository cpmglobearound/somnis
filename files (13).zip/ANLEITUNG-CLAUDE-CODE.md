# Klarframe — Scroll- & 3D-Erlebnis: Anleitung für Claude Code

Diese Anleitung beschreibt **was Claude Code für klarframe.com bauen kann, soll und ausdrücklich nicht soll**. Sie ist so geschrieben, dass du sie einem frischen Claude-Code-Lauf an die Hand geben kannst.

Im Lieferumfang dieses Bundles:

```
klarframe-scroll/
├── ANLEITUNG-CLAUDE-CODE.md          ← dieses Dokument (für dich)
├── CLAUDE.md                         ← in den Repo-Root kopieren (Projekt-Gedächtnis)
├── .claude/
│   └── skills/
│       └── scroll-3d/
│           ├── SKILL.md              ← das wiederverwendbare Rezept
│           └── references/
│               └── patterns.md       ← Code-Patterns (Lenis, GSAP, R3F, Perf, A11y)
└── components/
    └── hero/
        └── SystemField.tsx           ← lauffähiges Signature-Hero-Pattern
```

---

## 0. Die Leitidee (nicht überspringen)

Klarframe verkauft als Leistung **Nr. 10 „Interaktive Web-Erlebnisse"**. Die eigene Seite muss das **beweisen**, nicht behaupten. Gleichzeitig ist die Marke **ruhig, klar, seriös, anti-Lärm** („wir sind nicht hier, um mehr Lärm zu machen"). Das ergibt eine klare Design-Doktrin für jeden Effekt:

> **Ein einziger, perfekt sitzender Signature-Moment in echtem 3D — und überall sonst dezente, präzise Scroll-Choreografie. Zurückhaltung ist das Statement. Kein Reel-Zirkus.**

Das Leitmotiv ist inhaltlich vorgegeben durch die Headline („Nicht noch ein Tool — **ein System**, das mit Ihnen wächst") und „Tool-Chaos → ein System":

> **Chaos wird zu Ordnung.** Verstreute Punkte sammeln sich beim Scrollen zu einer klaren, vernetzten Struktur (einem „Frame"). Das bebildert die gesamte Markenbotschaft in einer Bewegung.

Jeder Effekt, den Claude Code baut, muss sich diesem Motiv unterordnen oder es verstärken. Effekte, die nur „cool" sind, aber die Botschaft nicht tragen, werden weggelassen.

---

## 1. Vorbereitung — bevor Claude Code irgendetwas baut

Diese Schritte führt Claude Code **zuerst** aus (read-only), damit es nichts blind überschreibt.

1. **Repo verstehen.** `package.json`, `next.config.*`, `tsconfig.json`, `tailwind.config.*` und die globale CSS-Datei lesen. Feststellen: Next.js-Version, React-Version (18 vs. 19), App-Router vs. Pages-Router, Tailwind v3 vs. v4, TypeScript ja/nein.
2. **Bestehendes Theme extrahieren.** Farben, Schrift, Spacing, Radius aus `globals.css` / Tailwind-Config auslesen und in `CLAUDE.md` unter „Design Tokens" eintragen. **Nicht erfinden** — die echten Klarframe-Werte verwenden. Die Platzhalter in `CLAUDE.md` werden ersetzt.
3. **Bestehende Animation inventarisieren.** Die Seite hat bereits Marquees (Text-Laufbänder), eine Testimonial-Schleife und Stat-Counter. Feststellen, womit die gebaut sind (CSS-Keyframes? Framer Motion? eigene Hooks?), um Doppelungen und Konflikte zu vermeiden.
4. **Branch anlegen.** `git checkout -b feature/scroll-experience`. Niemals direkt auf `main` arbeiten.

> **Regel:** Erst Phase 0 abschließen und das Ergebnis kurz zusammenfassen, dann erst installieren/bauen.

---

## 2. Stack & Installation

Claude Code installiert nur das, was zur erkannten React-Version passt:

| Paket | Zweck | Hinweis |
|---|---|---|
| `lenis` | Smooth-Scroll-Fundament | immer |
| `gsap` | ScrollTrigger-Choreografie | seit 2025 voll kostenlos inkl. aller Plugins |
| `three` | 3D-Engine | nur für die Hero-Szene |
| `@react-three/fiber` | React-Renderer für three | **v9 bei React 19 / Next 15, v8 bei React 18** |
| `@react-three/drei` | R3F-Helfer (Loader, Instances …) | Version passend zu fiber |
| `@react-three/postprocessing` | Bloom/DOF (optional) | nur wenn der Look es braucht — sparsam |
| `@types/three` (dev) | Typen | nur bei TypeScript |

CLI-Helfer (nicht installieren, per `npx` nutzen):
- `npx gltfjsx@latest model.glb` → wandelt ein GLB-Modell in eine React-Komponente.

**Wichtig:** R3F-Komponenten sind Client-Komponenten. Im App-Router muss die Hero-Datei `"use client"` tragen und per `next/dynamic` mit `{ ssr: false }` eingebunden werden (WebGL läuft nicht serverseitig).

---

## 3. MCP-Server für Assets (optional, aber stark)

Claude Code kann Assets direkt im Build-Loop erzeugen, statt manuell hin- und herzuspringen. Konfiguriere bei Bedarf in der Projekt-`.mcp.json` (oder `claude mcp add`):

- **Higgsfield** → `generate_3d` liefert GLB-Meshes für echte 3D-Szenen; `generate_video` liefert Clips für (sparsame) Scroll-Scrub-Akzente. Doku-Stand prüfen, da sich MCP-Tooling schnell ändert.
- **Figma** → Layout-/Referenz-Kontext einlesen, falls Designvorlagen existieren.

> Wenn keine MCP-Assets vorhanden sind: Die mitgelieferte `SystemField.tsx` braucht **kein** externes Asset — sie erzeugt die Punktwolke prozedural. Damit ist der Signature-Hero sofort lauffähig, GLB-Modelle sind eine spätere Veredelung.

---

## 4. Der Bauplan (Phasen) — was Claude Code tun SOLL

Reihenfolge ist bewusst: erst billig & risikoarm, dann teuer & sichtbar. Nach jeder Phase: bauen, im Browser prüfen, committen.

### Phase 1 — Smooth-Scroll-Fundament (geringes Risiko, sofort spürbar)
- Lenis global initialisieren (ein Provider/Hook ganz oben im Layout).
- GSAP ScrollTrigger an Lenis koppeln (`lenis.on('scroll', ScrollTrigger.update)` + `gsap.ticker`), sonst laufen beide auseinander.
- `prefers-reduced-motion` respektieren: ist es gesetzt, Lenis **nicht** aktivieren (nativer Scroll).
- Akzeptanzkriterium: Seite scrollt weich, nichts ruckelt, Anchor-Links (#services etc.) funktionieren weiterhin.

### Phase 2 — Scroll-Choreografie (GSAP, kein 3D)
Die vorhandenen Sektionen bekommen dezente, gestaffelte Bewegung:
- **Service-Cards 01–10:** beim Eintreten gestaffelt einblenden (kleiner y-Offset + Fade).
- **Vorher/Nachher-Sektion:** beim Scrollen vom „Vor Klarframe"- zum „Nach Klarframe"-Zustand überblenden (pinnen + Fortschritt mappen).
- **Journey 01–05:** Sektion pinnen, Schritte nacheinander aufdecken.
- **Stat-Counter (24/7, 10+, ∞):** beim Eintreten hochzählen.
- Maßhalten: kurze Distanzen, weiche Easings (`power2.out`), nichts „springt".

### Phase 3 — Signature-Hero in echtem 3D (das Herzstück)
- `components/hero/SystemField.tsx` einsetzen (mitgeliefert).
- Eine hohe Hero-Sektion (z. B. 200–250vh) mit gepinntem/sticky Canvas. Scroll-Fortschritt 0→1 treibt die Punktwolke von **Chaos → Frame**.
- Headline-Text liegt über dem Canvas und bleibt jederzeit lesbar (Kontrast prüfen).
- Brand-Farben aus den Tokens verwenden, **nicht** Neon. Maximal ein dezenter Akzent.
- Mobile: Partikelzahl drosseln; bei sehr schwachen Geräten / reduced-motion auf den **statischen Endzustand** (das fertige Frame) zurückfallen.

### Phase 4 — „Ganzheitlich"-Sektion als Node-Graph (optional, gleiches Motiv)
- Die „eine gemeinsame Intelligenzschicht"-Sektion als begehbaren 3D-Knotengraph, durch den man scrollt — greift das System-Motiv wieder auf (Wiedererkennung statt neuer Effekt).
- Nur bauen, wenn Phase 3 sauber sitzt und Performance-Budget bleibt.

### Phase 5 — Politur, Performance, Zugänglichkeit, Bugfix
- **OG-Image-Bug fixen:** Meta `og:image` / `twitter:image` zeigen auf `http://localhost:3000/klarframe.png` → auf `https://klarframe.com/klarframe.png` umstellen (Social-Sharing-Vorschau ist sonst leer). Schneller Gewinn.
- Lighthouse/Performance prüfen; Ziel: kein Layout-Shift, 60fps beim Scrollen, Canvas pausiert wenn außerhalb des Viewports (`frameloop="demand"` oder IntersectionObserver).
- WebGL-Fallback: Kein WebGL → statisches Hero-Bild.
- `cleanup`: alle ScrollTriggers und Lenis beim Unmount sauber killen (sonst Memory-Leaks bei Routenwechsel).

---

## 5. Was Claude Code ausdrücklich NICHT tun soll

- **Kein** lauter Reel-Look: keine Glitch-Portraits, kein „BOOM", keine Cyberpunk-Neonfarben, keine Effekte ohne inhaltlichen Bezug.
- **Kein** Video-Scrub als Leitmotiv. Höchstens ein einzelner Produkt-/Avatar-Akzent — und nur wenn Performance es trägt.
- **Keine** neue UI-Bibliothek oder neues Framework einführen, ohne zu fragen. In das bestehende Next.js/Tailwind-Setup integrieren, nicht ersetzen.
- **Kein** `localStorage`/`sessionStorage`-Experiment, das den bestehenden i18n-Flow (de/en/es) bricht.
- **Nichts** auf `main` pushen; keine `package.json`-Major-Upgrades ohne Rückfrage.
- **Keine** Accessibility-Verschlechterung: Tastatur-Navigation, Fokus und `prefers-reduced-motion` bleiben funktionsfähig.

---

## 6. Paste-fertige Prompts für Claude Code

Diese kannst du der Reihe nach in Claude Code eingeben.

**Prompt 0 — Audit**
```
Lies CLAUDE.md und .claude/skills/scroll-3d/SKILL.md. Führe dann Phase 0 aus der
ANLEITUNG aus: analysiere package.json, next.config, tsconfig, tailwind und globals.css.
Trage die echten Design-Tokens in CLAUDE.md ein und fasse zusammen, welche
React-/Next-/Tailwind-Versionen vorliegen und wie die bestehenden Animationen gebaut sind.
Installiere noch nichts.
```

**Prompt 1 — Fundament**
```
Setze Phase 1 um: Lenis global + GSAP ScrollTrigger korrekt gekoppelt, inkl.
prefers-reduced-motion-Fallback und sauberem Cleanup. Halte dich an die Patterns in
.claude/skills/scroll-3d/references/patterns.md. Danach build + kurzer Testbericht.
```

**Prompt 2 — Choreografie**
```
Phase 2: dezente GSAP-Scroll-Choreografie für Service-Cards, Vorher/Nachher, Journey
und Stat-Counter. Marken-Doktrin beachten (ruhig, kurz, weich). Keine bestehende
Funktion brechen.
```

**Prompt 3 — Signature-Hero**
```
Phase 3: binde components/hero/SystemField.tsx als Signature-Hero ein (sticky Canvas,
~220vh Sektion, Scroll treibt Chaos→Frame). Nutze die echten Brand-Tokens, halte die
Headline lesbar, drossle auf Mobile, Fallback auf statischen Endzustand bei
reduced-motion / kein WebGL.
```

**Prompt 4 — Bugfix + Politur**
```
Phase 5: fixe den og:image/twitter:image localhost-Bug, miss Performance, sorge für
60fps und kein Layout-Shift, pausiere den Canvas außerhalb des Viewports, prüfe
Tastatur-/Fokus-Verhalten. Erstelle einen kurzen QA-Bericht.
```

---

## 7. Definition of Done

- [ ] Smooth Scroll aktiv, Anchor-Navigation intakt, `prefers-reduced-motion` respektiert.
- [ ] Signature-Hero läuft mit 60fps auf Desktop, gedrosselt/Fallback auf Mobile.
- [ ] Effekte tragen das „Chaos→System"-Motiv; nichts ist bloßer Show-Effekt.
- [ ] og:image zeigt auf eine öffentliche URL; Social-Preview funktioniert.
- [ ] Kein Memory-Leak bei Routenwechsel (ScrollTrigger/Lenis sauber gekillt).
- [ ] Brand bleibt ruhig/klar — ein Reviewer würde *nicht* sagen „sieht aus wie ein AI-Reel".
- [ ] Alles auf `feature/scroll-experience`, sauber committet, PR-bereit.
